// DOM elements
const productForm = document.getElementById('productForm');
const productList = document.getElementById('productList');
const searchBar = document.getElementById('searchBar');

// Load products from localStorage
const products = JSON.parse(localStorage.getItem('products')) || [];

// Handle form submission to add product
if (productForm) {
    productForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const productName = document.getElementById('productName').value;
        const productPrice = document.getElementById('productPrice').value;

        if (productName && productPrice) {
            const product = { name: productName, price: productPrice };
            products.push(product);
            localStorage.setItem('products', JSON.stringify(products));
            alert('Product added successfully ');
        }

        productForm.reset();
    });
}

// Render products on the product list page
if (productList) {
    renderProducts(products);

    // Add event listener for search
    searchBar.addEventListener('keyup', function() {
        const searchValue = searchBar.value.toLowerCase();
        const filteredProducts = products.filter(product => 
            product.name.toLowerCase().includes(searchValue));
        renderProducts(filteredProducts);
    });
}

// Function to render products
function renderProducts(productsToRender) {
    productList.innerHTML = '';
    productsToRender.forEach((product, index) => {
        const li = document.createElement('li');
        li.innerHTML = `${product.name} - ₹${product.price} <button class="delete-btn" data-index="${index}">Delete</button>`;
        productList.appendChild(li);

        const deleteBtn = li.querySelector('.delete-btn');
        deleteBtn.addEventListener('click', function() {
            deleteProduct(index);
        });
    });
}

// Function to delete a product
function deleteProduct(index) {
    products.splice(index, 1);
    localStorage.setItem('products', JSON.stringify(products));
    renderProducts(products);
}
function goToProductPage() {
    window.location.href = 'products.html';  // or the correct relative path
}
